rm *.{html,md,txt}
rm -r awesome_figs
