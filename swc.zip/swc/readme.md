This directory contains:

swc-git - our practice git lesson
sql_lesson - the sql lesson with data and a few extra scripts that we put together during the lesson
shell-novice - the shell lesson
r-novice - the lesson material for novice r lesson
2015-01-08-NIH-github - the practice workflow with shell script