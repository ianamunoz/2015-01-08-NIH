analyze <- function(filename = NULL ,data){
  #comments 
  #TODO check to make first argument is a character string
  if( is.null(filename)){
    message("Give a filename")
  } else {
    
  png(file = filename)
  par(mfrow = c(2,2))
  avg_day_inflammation <- apply(data,2,mean)
  plot(avg_day_inflammation)
  
  max_day_inflammation <- apply(data,2,max)
  plot(max_day_inflammation)
  
  min_day_inflammation <- apply(data,2,min)
  plot(min_day_inflammation)
  dev.off()
  message(c(filename, " was saved"))
  }
}