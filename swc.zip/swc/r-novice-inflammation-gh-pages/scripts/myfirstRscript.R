# TODO read in the first input  "data/inflammation-01.csv"
# Use analyze function to print the plots file
# second command line argument should be the name of the 
# plots

#load my function
source("scripts/functions.r")

args <- commandArgs(trailingOnly = TRUE)
#cat(args)
#cat(args, sep = "\n")
filenamein <- args[1]
cat(filenamein)
filenameout <- args[2]

dat <- read.csv(filenamein , header=FALSE)

analyze(filenameout, dat)

