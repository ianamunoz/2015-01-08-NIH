dat <- read.csv("data/inflammation-01.csv", header=FALSE)

weight_kg <- 55

weight_lbs <- 2.2 * weight_kg

i <- 1
j <- 3

patient_1 <- dat[i,]


mass <- 47.5
age <- 122
mass <- mass * 2.0

min(dat)

min(dat[i,])

min(patient_1)

mean(as.numeric(patient_1))

avg_patient_inflammation <- apply(dat,1,mean)


avg_patient_inflammation[32]

element <- c("o", "x", "y", "g","e","n")
element[1:3]
element[4:6]
element[4:1]
element[5:6]

c(element[5], element[1], element[6])

c(element,element)

element[c(5,1,6)]

seq(1,10,2)



element[(length(element)-1):length(element)]

patient1<- "tomcat20150113"
patient2<- "bobdole20150315"

# look at the inflammation over time
avg_day_inflammation <- apply(dat,2,mean)
plot(avg_day_inflammation)

max_day_inflammation <- apply(dat,2,max)
plot(max_day_inflammation)

min_day_inflammation <- apply(dat,2,min)
plot(min_day_inflammation)

sd

sd_day_inflammation <- apply(dat,2,sd)
plot(sd_day_inflammation)

dat$day1

colnames(dat)[1]<-"day1"

row.names(dat)

tdat <- t(dat)


kelvin_to_celsius <- function(temp){
  
  celsius <- temp - 273.14
  return(celsius)
  
}
  
kelvin_to_celsius(400)

element 

fence <- function(charvec) {
  
  charvec <- c("***",charvec, "***")  
  charvec
}

































