library(dplyr)
library(nycflights13)

my_db <- src_sqlite("my_db.sqlite3", create = T)

flights_sqlite <- copy_to(my_db, flights, temporary = FALSE, indexes = list(
  c("year","month","day"),"carrier", "tailnum"))

testdata<-flights_sqlite %>%
          select(year:day,dep_delay,arr_delay) %>%
          filter(dep_delay >240) %>%
          arrange(year,month,day)


testdf <- data.frame(testdata)
