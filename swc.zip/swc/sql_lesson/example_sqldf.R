library(sqldf)

db <- dbConnect(drv = SQLite(), dbname="data/portal_mammals.sqlite")

dbListTables(db)

firstobj <- dbGetQuery(conn = db, "SELECT record_id, month, day, year, plot, species, sex, wgt, species_id
            FROM surveys
            JOIN species ON surveys.species = species.species_id;")

query <- "SELECT * FROM ians_view"

secondobj <- dbGetQuery(conn = db, query)
  
dbWriteTable(conn = db,"ianstable", secondobj )

inflammation01 <- read.csv(file = "..//r-novice-inflammation-gh-pages//data/inflammation-01.csv")

dbWriteTable(conn = db,"ianstable2", inflammation01  )
dbWriteTable(conn = db,"ianstable3", value = "..//r-novice-inflammation-gh-pages//data/inflammation-01.csv")

dbWriteTable(conn = db,"ianstable3", value = "..//r-novice-inflammation-gh-pages//data/inflammation-02.csv",append = TRUE)

dbListTables(db)
dbDisconnect(db)












