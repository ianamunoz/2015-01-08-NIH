cat "$3" | sort -n | head -n "$1" | tail -n "$2"
