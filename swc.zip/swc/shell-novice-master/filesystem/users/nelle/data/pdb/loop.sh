for filename in *.pdb
do
	echo $filename
	bash middle.sh 35 10 $filename
done

