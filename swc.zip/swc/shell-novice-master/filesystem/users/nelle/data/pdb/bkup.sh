for filename in *.pdb
do
	echo $filename
	cp $filename ${filename}{1..2}
done

