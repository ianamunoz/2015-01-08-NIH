shell-novice
============

First encounter with the Unix shell.
